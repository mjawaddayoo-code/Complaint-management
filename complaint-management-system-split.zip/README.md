# Complaint Management System

Split into two independent projects:

```
backend/    Express + MongoDB REST API   → see backend/README.md
frontend/   React (Vite) single-page app → see frontend/README.md
```

They run as two separate servers and talk over HTTP.

## Quick start

Terminal 1 — API:
```
cd backend
npm install
cp .env.example .env    # fill in MONGO_URI, SESSION_SECRET, ADMIN_PASSWORD, mail settings
npm run dev
```

Terminal 2 — frontend:
```
cd frontend
npm install
cp .env.example .env    # defaults to http://localhost:3000, change if needed
npm run dev
```

Then open `http://localhost:5173`.

## Flow

Register → Login → Submit Complaint → saved to MongoDB → admin email
notification → Admin login (separate password, not a DB user) → Admin
reviews complaints (stats, search, filter, pagination, details with a
notification-delivery timeline).

See `backend/README.md` for the full API reference and
`frontend/README.md` for the app structure. **If you're migrating from an
earlier version with credentials hardcoded in source, rotate them** — see
the warning at the top of `backend/README.md`.
